-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 27, 2022 at 08:11 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sports_club_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact_tbl`
--

CREATE TABLE `contact_tbl` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `phonenumber` int(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `message` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact_tbl`
--

INSERT INTO `contact_tbl` (`id`, `name`, `phonenumber`, `email`, `message`) VALUES
(1, 'Ajay Maru', 2147483647, 'ajaymaru.r2001@gmail.com', 'bugyufguhygygy7t67'),
(2, 'Ajay Maru', 2147483647, 'ajaymaru.r2001@gmail.com', 'bugyufguhygygy7t67'),
(3, 'Ajay Maru', 2147483647, 'ajaymaru.r2001@gmail.com', 'jbhuygyyuguigyftyfyg'),
(4, 'Ajay rakesh', 2147483647, 'maruajay603@gmail.com', 'bjgugyug');

-- --------------------------------------------------------

--
-- Table structure for table `feedback_tbl`
--

CREATE TABLE `feedback_tbl` (
  `id` int(11) DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `message` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback_tbl`
--

INSERT INTO `feedback_tbl` (`id`, `name`, `email`, `message`) VALUES
(NULL, 'Danis', 'danish07@gmail.com', 'your website is very helpfull and very user friendly..\r\nthank you...');

-- --------------------------------------------------------

--
-- Table structure for table `tournament_tbl`
--

CREATE TABLE `tournament_tbl` (
  `id` int(11) DEFAULT NULL,
  `clgname` varchar(100) NOT NULL,
  `tname` varchar(100) NOT NULL,
  `cname` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `pincode` int(6) NOT NULL,
  `mnumber` int(10) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tournament_tbl`
--

INSERT INTO `tournament_tbl` (`id`, `clgname`, `tname`, `cname`, `city`, `pincode`, `mnumber`, `email`) VALUES
(NULL, 'tarsadiya university ', 'black adom', 'vraj patel', 'surat', 394107, 2147483647, 'vraj07@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `user_tbl`
--

CREATE TABLE `user_tbl` (
  `id` int(20) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `cpassword` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_tbl`
--

INSERT INTO `user_tbl` (`id`, `username`, `email`, `password`, `cpassword`) VALUES
(3, 'Ajay', 'maruajay603@gmail.com', 'ajay007', 'ajay007'),
(4, 'Atrey', 'atrey12@gmail.com', 'atrey123', 'atrey123'),
(5, 'tanna yash', 'yash12@gmail.com', 'yash123', 'yash123'),
(6, 'Atrey', 'piyush12@gmail.com', 'atrey123', 'atrey123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact_tbl`
--
ALTER TABLE `contact_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback_tbl`
--
ALTER TABLE `feedback_tbl`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `tournament_tbl`
--
ALTER TABLE `tournament_tbl`
  ADD PRIMARY KEY (`pincode`);

--
-- Indexes for table `user_tbl`
--
ALTER TABLE `user_tbl`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact_tbl`
--
ALTER TABLE `contact_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tournament_tbl`
--
ALTER TABLE `tournament_tbl`
  MODIFY `pincode` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=784597;

--
-- AUTO_INCREMENT for table `user_tbl`
--
ALTER TABLE `user_tbl`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
